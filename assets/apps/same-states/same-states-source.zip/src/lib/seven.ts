export function norm7(r: number): number {
  return ((r % 7) + 7) % 7;
}

export function complement7(r: number): number {
  return (7 - norm7(r)) % 7;
}

/** Plain doubling is ×2. Composing with complement makes ×5. Reverse walks the inverse: ×4 or ×3. */
export function multiplier7(compose: boolean, reverse: boolean): number {
  const forward = compose ? 5 : 2;
  if (!reverse) return forward;
  for (let k = 1; k < 7; k++) {
    if ((forward * k) % 7 === 1) return k;
  }
  return 1;
}

export function step7(r: number, compose: boolean, reverse = false): number {
  return (multiplier7(compose, reverse) * norm7(r)) % 7;
}

export function orbit7(start: number, compose: boolean, reverse = false): number[] {
  const out: number[] = [];
  const seen = new Set<number>();
  let x = norm7(start);
  while (!seen.has(x)) {
    seen.add(x);
    out.push(x);
    x = step7(x, compose, reverse);
  }
  return out;
}

export function bits7(r: number): string {
  return norm7(r).toString(2).padStart(3, "0");
}
