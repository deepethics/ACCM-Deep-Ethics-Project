export type Mode = "decimal" | "half" | "binary" | "vigesimal";

export const MOD = 21;

/** Days around each street, in the order ×10 walks them. */
export const DAY_ORDER = [1, 3, 2, 6, 4, 5] as const;

const MULTIPLIER: Record<Mode, number> = {
  decimal: 10,
  half: 13,
  binary: 2,
  vigesimal: 20,
};

export function norm(r: number): number {
  return ((r % MOD) + MOD) % MOD;
}

export function laneOf(r: number): number {
  return norm(r) % 3;
}

export function dayOf(r: number): number {
  return norm(r) % 7;
}

export function step(r: number, mode: Mode): number {
  return (MULTIPLIER[mode] * norm(r)) % MOD;
}

export function complement(r: number): number {
  return (MOD - norm(r)) % MOD;
}

export function isMirror(r: number, mode: Mode): boolean {
  const x = norm(r);
  return x !== 0 && step(x, mode) === complement(x);
}

export function orbit(start: number, mode: Mode): number[] {
  const out: number[] = [];
  const seen = new Set<number>();
  let x = norm(start);
  while (!seen.has(x)) {
    seen.add(x);
    out.push(x);
    x = step(x, mode);
  }
  return out;
}

export function decimalBlock(r: number): string {
  return String((47619 * norm(r)) % 999999).padStart(6, "0");
}

export function binaryBlock(r: number): string {
  return ((3 * norm(r)) % 63).toString(2).padStart(6, "0");
}

export function vigesimalDigits(r: number): [number, number] {
  const x = norm(r);
  if (x === 0) return [0, 0];
  return [x - 1, 20 - x];
}

export function glyph(d: number): string {
  if (d < 10) return String(d);
  return "ABCDEFGHIJ"[d - 10] ?? String(d);
}

export const MODE_META: Record<
  Mode,
  { label: string; factor: string; line: string }
> = {
  decimal: {
    label: "Decimal",
    factor: "×10",
    line: "The street stays. Only the week turns. One step is a short walk around the ring, not yet the complement. 0, 7, and 14 stay.",
  },
  half: {
    label: "Half-turn",
    factor: "×10³",
    line: "Three decimal steps flip the week and stay on the street. That lands on the complement only on the inner street, where the 3-counter is already zero. 0, 7, and 14 stay.",
  },
  binary: {
    label: "Binary",
    factor: "×2",
    line: "Two six-cycles among the twelve units, swapping the outer streets. The inner street splits into two triangles. The step itself meets the complement only at 7 and 14. 0 stays.",
  },
  vigesimal: {
    label: "Base 20",
    factor: "×20",
    line: "Twenty is −1 modulo 21, so one step flips both counters. Turning around and crossing the street are the same arrow. Every pair is a pendulum. 0 stays; 7 and 14 exchange.",
  },
};

/** What the walk becomes after composing the selected step with complement. */
export const COMPOSED_META: Record<Mode, { factor: string; line: string }> = {
  decimal: {
    factor: "×11",
    line: "Composed with −1, decimal is ×11. The outer streets trade in two six-cycles, and the inner street breaks into two triangles. One step reaches the complement only at 7 and 14.",
  },
  half: {
    factor: "×8",
    line: "Composed with −1, the half-turn is ×8. The week stays and the street flips, so the whole inner street is still. 7 and 14 exchange, and that pair is the complement.",
  },
  binary: {
    factor: "×19",
    line: "Composed with −1, binary is ×19. Each street turns on its own: one six-cycle inside, one on each outer street. 0, 7, and 14 stay. No single arrow is the complement.",
  },
  vigesimal: {
    factor: "×1",
    line: "Composed with −1, base 20 is ×1, because (−1)×20 ≡ 1. Every state stays. The dashed chord is still the complement; the walk has paused.",
  },
};

export function walkingMultiplier(mode: Mode, compose: boolean): number {
  const plain = MULTIPLIER[mode];
  return compose ? (MOD - plain) % MOD : plain;
}

const SETTINGS: { mode: Mode; compose: boolean }[] = (Object.keys(MULTIPLIER) as Mode[]).flatMap(
  (mode) => [
    { mode, compose: false },
    { mode, compose: true },
  ],
);

/** The undo is another offered setting: same roads, opposite arrows. */
export function inverseSetting(mode: Mode, compose: boolean): {
  mode: Mode;
  compose: boolean;
  factor: string;
  self: boolean;
} {
  const m = walkingMultiplier(mode, compose);
  let inv = 1;
  for (let k = 1; k < MOD; k++) {
    if ((m * k) % MOD === 1) inv = k;
  }
  const found = SETTINGS.find((s) => walkingMultiplier(s.mode, s.compose) === inv);
  if (!found) throw new Error(`no undo setting for ×${m}`);
  const factor = found.compose ? COMPOSED_META[found.mode].factor : MODE_META[found.mode].factor;
  return {
    ...found,
    factor,
    self: found.mode === mode && found.compose === compose,
  };
}
