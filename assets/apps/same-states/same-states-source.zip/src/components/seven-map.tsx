import { useEffect, useId, useState } from "react";
import { Pause, Play } from "lucide-react";
import { bits7, complement7, multiplier7, orbit7, step7 } from "@/lib/seven";

const LEFT = { x: 210, y: 210 };
const RIGHT = { x: 510, y: 210 };
const RAD = 108;
const CYCLE = [1, 2, 4] as const;

type Pt = { x: number; y: number };

function pointOf(r: number): Pt {
  const x = ((r % 7) + 7) % 7;
  if (x === 0) return { x: 360, y: 430 };
  const onLeft = x === 1 || x === 2 || x === 4;
  const base = onLeft ? x : complement7(x);
  const i = CYCLE.indexOf(base as (typeof CYCLE)[number]);
  const center = onLeft ? LEFT : RIGHT;
  const ang = -Math.PI / 2 + i * ((2 * Math.PI) / 3);
  return { x: center.x + RAD * Math.cos(ang), y: center.y + RAD * Math.sin(ang) };
}

function arrowPath(fromR: number, toR: number): string {
  const a = pointOf(fromR);
  const b = pointOf(toR);
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const len = Math.hypot(dx, dy) || 1;
  const start = { x: a.x + (dx / len) * 18, y: a.y + (dy / len) * 18 };
  const end = { x: b.x - (dx / len) * 22, y: b.y - (dy / len) * 22 };
  const mx = (start.x + end.x) / 2;
  const my = (start.y + end.y) / 2;
  const leftish = mx < 360;
  const center = leftish ? LEFT : RIGHT;
  const rx = mx - center.x;
  const ry = my - center.y;
  const radial = Math.hypot(rx, ry) || 1;
  const same =
    (fromR === 1 || fromR === 2 || fromR === 4) === (toR === 1 || toR === 2 || toR === 4);
  const px = -dy / len;
  const py = dx / len;
  const bow = same ? 0 : fromR < toR ? 14 : -14;
  const out = same ? 28 : 0;
  return `M ${start.x} ${start.y} Q ${mx + (rx / radial) * out + px * bow} ${my + (ry / radial) * out + py * bow} ${end.x} ${end.y}`;
}

export function SevenMap() {
  const markerId = useId().replace(/:/g, "");
  const [residue, setResidue] = useState(1);
  const [playing, setPlaying] = useState(true);
  const [compose, setCompose] = useState(false);
  const [reverse, setReverse] = useState(false);

  useEffect(() => {
    if (!playing) return;
    const id = window.setInterval(() => {
      setResidue((r) => step7(r, compose, reverse));
    }, 1300);
    return () => window.clearInterval(id);
  }, [playing, compose, reverse]);

  const walk = orbit7(residue, compose, reverse);
  const onWalk = new Set(walk);
  const next = step7(residue, compose, reverse);
  const other = complement7(residue);
  const mirrorHere = residue !== 0 && next === other;
  const showMirror = other !== residue && other !== next;
  const here = pointOf(residue);

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          aria-pressed={compose}
          onClick={() => setCompose((v) => !v)}
          className={
            "min-h-11 rounded-full border px-3 py-2 font-mono text-sm " +
            (compose ? "border-accent bg-accent text-ink" : "border-line bg-surface text-fg")
          }
        >
          Compose −1
        </button>
        <button
          type="button"
          aria-pressed={reverse}
          onClick={() => setReverse((v) => !v)}
          className={
            "min-h-11 rounded-full border px-3 py-2 font-mono text-sm " +
            (reverse ? "border-accent bg-accent text-ink" : "border-line bg-surface text-fg")
          }
        >
          Retrace
          <span className="ml-2 font-serif">×{multiplier7(compose, true)}</span>
        </button>
        <button
          type="button"
          onClick={() => setPlaying((v) => !v)}
          className="inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-surface px-3 py-2 text-fg"
          aria-pressed={playing}
        >
          {playing ? <Pause className="size-4" aria-hidden /> : <Play className="size-4" aria-hidden />}
          {playing ? "Pause" : "Walk"}
        </button>
      </div>

      <div className="overflow-hidden rounded-2xl border border-line bg-surface">
        <p className="px-4 pt-4 font-mono text-xs tracking-wide text-faint uppercase">
          {reverse
            ? `Retrace ×${multiplier7(compose, true)}`
            : compose
              ? "Step ×5"
              : "Step ×2"}
        </p>
        <svg viewBox="0 0 720 520" className="h-auto w-full" role="img" aria-label="Seven residues as two triangles">
          <defs>
            <marker
              id={markerId}
              viewBox="0 0 10 10"
              refX="8"
              refY="5"
              markerWidth="7"
              markerHeight="7"
              orient="auto-start-reverse"
            >
              <path d="M 1 1.5 L 8 5 L 1 8.5" fill="none" stroke="context-stroke" strokeWidth="1.6" />
            </marker>
          </defs>
          <circle cx={LEFT.x} cy={LEFT.y} r={RAD} fill="none" className="stroke-line" />
          <circle cx={RIGHT.x} cy={RIGHT.y} r={RAD} fill="none" className="stroke-line" />
          <text x={LEFT.x} y={LEFT.y + RAD + 28} textAnchor="middle" className="fill-faint font-mono" fontSize="12">
            1 · 2 · 4
          </text>
          <text x={RIGHT.x} y={RIGHT.y + RAD + 28} textAnchor="middle" className="fill-faint font-mono" fontSize="12">
            3 · 6 · 5
          </text>
          {showMirror ? (
            <path
              d={arrowPath(residue, other)}
              fill="none"
              className="stroke-muted"
              strokeWidth="1.4"
              strokeDasharray="4 6"
              markerEnd={`url(#${markerId})`}
            />
          ) : null}
          {walk.map((r) => {
            const to = step7(r, compose, reverse);
            if (to === r) return null;
            return (
              <path
                key={r}
                d={arrowPath(r, to)}
                fill="none"
                markerEnd={`url(#${markerId})`}
                strokeWidth="1.8"
                className="flow stroke-accent"
              />
            );
          })}
          {Array.from({ length: 7 }, (_, r) => {
            const p = pointOf(r);
            const on = r === residue;
            return (
              <g
                key={r}
                role="button"
                tabIndex={0}
                aria-label={`Residue ${r}`}
                aria-pressed={on}
                className="cursor-pointer"
                opacity={onWalk.has(r) ? 1 : 0.38}
                onClick={() => setResidue(r)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    setResidue(r);
                  }
                }}
              >
                <circle cx={p.x} cy={p.y} r="22" fill="transparent" />
                <circle
                  cx={p.x}
                  cy={p.y}
                  r="16"
                  strokeWidth="1.5"
                  className={on ? "fill-accent stroke-accent" : "fill-bg stroke-line"}
                />
                <text
                  x={p.x}
                  y={p.y + 1}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fontSize="13"
                  className={on ? "fill-ink font-mono" : "fill-fg font-mono"}
                  pointerEvents="none"
                >
                  {r}
                </text>
              </g>
            );
          })}
          <circle className="token fill-accent" cx={here.x} cy={here.y - 28} r="5" pointerEvents="none" />
        </svg>
      </div>

      <p className="max-w-xl text-lg leading-snug text-fg">
        {compose
          ? "Composing complement with doubling is ×5. It merges the triangles into one six-cycle. The dashed chord is still the complement alone."
          : "Doubling, ×2, stays on its triangle. −1 is not a power of 2, so the complement has to cross."}
      </p>
      <p className="max-w-xl text-sm text-muted">
        {reverse
          ? compose
            ? "Retrace walks ×3, the inverse of ×5. Same six-cycle, opposite arrows. Five forward steps reach that neighbor, because 5⁵ ≡ 3. Two steps are only ×4."
            : "Retrace walks ×4, the inverse of ×2. Same triangle, opposite arrows. Two forward steps reach that neighbor, because 2² ≡ 4."
          : compose
            ? "Undo is ×3. No named setting is that multiplier, so Retrace walks the inverse itself. Five steps of this cycle equal one step back. Two steps do not."
            : "Undo is ×4. No named setting is that multiplier, so Retrace walks the inverse itself. On this triangle, two forward steps equal that one step back."}
      </p>

      <div>
        <p className="font-mono text-xs tracking-wide text-faint uppercase">Residue {residue}</p>
        <div className="mt-2 flex gap-1" aria-label="Binary block">
          {bits7(residue)
            .split("")
            .map((ch, i) => (
              <span
                key={i}
                className="flex h-12 w-9 items-center justify-center rounded-md bg-surface font-mono text-xl text-fg tabular-nums"
              >
                {ch}
              </span>
            ))}
        </div>
        <p className="mt-2 max-w-md text-sm text-muted">
          {residue === 0
            ? "Zero stays."
            : mirrorHere
              ? "This arrow is the complement."
              : "The dashed chord is the complement. This step does not take it."}
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          {walk.map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setResidue(r)}
              className={
                "min-h-11 min-w-11 rounded-full border font-mono text-sm " +
                (r === residue ? "border-accent bg-accent text-ink" : "border-line bg-surface text-fg")
              }
            >
              {r}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
