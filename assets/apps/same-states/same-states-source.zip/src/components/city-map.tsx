import { useEffect, useId, useState } from "react";
import { Pause, Play } from "lucide-react";
import {
  DAY_ORDER,
  COMPOSED_META,
  MODE_META,
  binaryBlock,
  complement,
  dayOf,
  decimalBlock,
  glyph,
  inverseSetting,
  laneOf,
  step,
  vigesimalDigits,
  type Mode,
} from "@/lib/city";

const CX = 360;
const CY = 318;
const RADII = [108, 186, 264] as const;
const HUB_Y = CY + RADII[2] + 58;

type Pt = { x: number; y: number };

function pointOf(r: number): Pt {
  const lane = laneOf(r);
  const day = dayOf(r);
  if (day === 0) {
    return { x: CX + (lane - 1) * 88, y: HUB_Y };
  }
  const i = DAY_ORDER.indexOf(day as (typeof DAY_ORDER)[number]);
  const ang = -Math.PI / 2 + i * (Math.PI / 3);
  const rad = RADII[lane];
  return { x: CX + rad * Math.cos(ang), y: CY + rad * Math.sin(ang) };
}

function arrowPath(fromR: number, toR: number): string {
  const a = pointOf(fromR);
  const b = pointOf(toR);
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const len = Math.hypot(dx, dy) || 1;
  const start = { x: a.x + (dx / len) * 18, y: a.y + (dy / len) * 18 };
  const end = { x: b.x - (dx / len) * 22, y: b.y - (dy / len) * 22 };
  const mx = (start.x + end.x) / 2;
  const my = (start.y + end.y) / 2;
  const rx = mx - CX;
  const ry = my - CY;
  const radial = Math.hypot(rx, ry) || 1;
  const sameStreet = laneOf(fromR) === laneOf(toR) && dayOf(fromR) !== 0 && dayOf(toR) !== 0;
  const fromDay = DAY_ORDER.indexOf(dayOf(fromR) as (typeof DAY_ORDER)[number]);
  const toDay = DAY_ORDER.indexOf(dayOf(toR) as (typeof DAY_ORDER)[number]);
  const antipode = sameStreet && fromDay >= 0 && (toDay - fromDay + 6) % 6 === 3;
  const px = -dy / len;
  const py = dx / len;
  const bow = antipode || !sameStreet ? (fromR < toR ? 16 : -16) : 0;
  const out = sameStreet && !antipode ? 32 : 0;
  const qx = mx + (rx / radial) * out + px * bow;
  const qy = my + (ry / radial) * out + py * bow;
  return `M ${start.x} ${start.y} Q ${qx} ${qy} ${end.x} ${end.y}`;
}

const MODES: Mode[] = ["decimal", "half", "binary", "vigesimal"];

function blockChars(r: number, mode: Mode): string[] {
  if (mode === "binary") return binaryBlock(r).split("");
  if (mode === "vigesimal") return vigesimalDigits(r).map(glyph);
  return decimalBlock(r).split("");
}

export function CityMap() {
  const markerId = useId().replace(/:/g, "");
  const [mode, setMode] = useState<Mode>("decimal");
  const [residue, setResidue] = useState(3);
  const [playing, setPlaying] = useState(true);
  const [compose, setCompose] = useState(false);

  function advance(r: number) {
    const plain = step(r, mode);
    return compose ? complement(plain) : plain;
  }

  function orbitFrom(start: number) {
    const out: number[] = [];
    const seen = new Set<number>();
    let x = ((start % 21) + 21) % 21;
    while (!seen.has(x)) {
      seen.add(x);
      out.push(x);
      x = advance(x);
    }
    return out;
  }

  useEffect(() => {
    if (!playing) return;
    const id = window.setInterval(() => {
      setResidue((r) => {
        const plain = step(r, mode);
        return compose ? complement(plain) : plain;
      });
    }, 1300);
    return () => window.clearInterval(id);
  }, [playing, mode, compose]);

  const walk = orbitFrom(residue);
  const onWalk = new Set(walk);
  const next = advance(residue);
  const other = complement(residue);
  const mirrorHere = residue !== 0 && next === other;
  const showMirror = other !== residue && other !== next;
  const chars = blockChars(residue, mode);
  const undo = inverseSetting(mode, compose);
  const here = pointOf(residue);
  const out = Math.hypot(here.x - CX, here.y - CY);
  const token =
    out < 24
      ? { x: here.x, y: here.y - 26 }
      : { x: here.x + ((here.x - CX) / out) * 24, y: here.y + ((here.y - CY) / out) * 24 };

  return (
    <div className="flex flex-col gap-5">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4" role="radiogroup" aria-label="Which shift">
        {MODES.map((m) => {
          const on = m === mode;
          return (
            <button
              key={m}
              type="button"
              role="radio"
              aria-checked={on}
              onClick={() => setMode(m)}
              className={
                "min-h-11 rounded-full border px-3 py-2 text-left font-mono text-sm " +
                (on ? "border-accent bg-accent text-ink" : "border-line bg-surface text-fg")
              }
            >
              {MODE_META[m].factor}
              <span className="ml-2 font-serif">{MODE_META[m].label}</span>
            </button>
          );
        })}
      </div>
      <button
        type="button"
        aria-pressed={compose}
        onClick={() => setCompose((v) => !v)}
        className={
          "min-h-11 w-fit rounded-full border px-3 py-2 text-left font-mono text-sm " +
          (compose ? "border-accent bg-accent text-ink" : "border-line bg-surface text-fg")
        }
      >
        Compose −1
        <span className="ml-2 font-serif">
          {compose ? "arrows are the step, then the complement" : "leave the complement dashed"}
        </span>
      </button>
      {undo.self ? null : (
        <button
          type="button"
          onClick={() => {
            setMode(undo.mode);
            setCompose(undo.compose);
          }}
          className="min-h-11 w-fit rounded-full border border-line bg-surface px-3 py-2 text-left font-mono text-sm text-fg"
        >
          Retrace
          <span className="ml-2 font-serif">
            {MODE_META[undo.mode].label}
            {undo.compose ? ", then complement" : ""}
          </span>
        </button>
      )}

      <div className="overflow-hidden rounded-2xl border border-line bg-surface">
        <div className="flex items-center justify-between gap-3 px-4 pt-4">
          <p className="font-mono text-xs tracking-wide text-faint uppercase">
            Street {laneOf(residue)} · day {dayOf(residue)}
          </p>
          <button
            type="button"
            onClick={() => setPlaying((v) => !v)}
            className="inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-bg px-3 py-2 text-fg"
            aria-pressed={playing}
          >
            {playing ? <Pause className="size-4" aria-hidden /> : <Play className="size-4" aria-hidden />}
            {playing ? "Pause" : "Walk"}
          </button>
        </div>
        <svg viewBox="0 0 720 720" className="h-auto w-full" role="img" aria-label="Twenty-one residues on three streets">
          <defs>
            <marker
              id={markerId}
              viewBox="0 0 10 10"
              refX="8"
              refY="5"
              markerWidth="7"
              markerHeight="7"
              orient="auto-start-reverse"
            >
              <path d="M 1 1.5 L 8 5 L 1 8.5" fill="none" stroke="context-stroke" strokeWidth="1.6" />
            </marker>
          </defs>

          {RADII.map((rad) => (
            <circle key={rad} cx={CX} cy={CY} r={rad} fill="none" className="stroke-line" strokeWidth="1" />
          ))}

          {RADII.map((rad, lane) => (
            <text
              key={lane}
              x={CX - rad - 14}
              y={CY + 4}
              textAnchor="end"
              className="fill-faint font-mono"
              fontSize="12"
            >
              {lane}
            </text>
          ))}

          {showMirror ? (
            <path
              d={arrowPath(residue, other)}
              fill="none"
              className="stroke-faint"
              strokeWidth="1.4"
              strokeDasharray="4 6"
              markerEnd={`url(#${markerId})`}
            />
          ) : null}

          {walk.map((r) => {
            const to = advance(r);
            if (to === r) return null;
            return (
              <path
                key={`a-${r}`}
                d={arrowPath(r, to)}
                fill="none"
                markerEnd={`url(#${markerId})`}
                strokeWidth="1.8"
                className="flow stroke-accent"
              />
            );
          })}

          <text x={CX} y={HUB_Y - 36} textAnchor="middle" className="fill-faint font-mono" fontSize="11">
            day 0
          </text>

          {Array.from({ length: 21 }, (_, r) => {
            const p = pointOf(r);
            const on = r === residue;
            const live = onWalk.has(r);
            const mirror = r !== 0 && advance(r) === complement(r);
            return (
              <g
                key={r}
                role="button"
                tabIndex={0}
                aria-label={`Residue ${r}, street ${laneOf(r)}, day ${dayOf(r)}`}
                aria-pressed={on}
                className="cursor-pointer"
                opacity={live ? 1 : 0.38}
                onClick={() => setResidue(r)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    setResidue(r);
                  }
                }}
              >
                <circle cx={p.x} cy={p.y} r="22" fill="transparent" />
                <circle
                  cx={p.x}
                  cy={p.y}
                  r="14"
                  strokeWidth="1.5"
                  className={
                    on
                      ? "fill-accent stroke-accent"
                      : mirror
                        ? "fill-bg stroke-accent"
                        : "fill-bg stroke-line"
                  }
                />
                <text
                  x={p.x}
                  y={p.y + 1}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fontSize="12"
                  className={on ? "fill-ink font-mono" : "fill-fg font-mono"}
                  pointerEvents="none"
                >
                  {r}
                </text>
              </g>
            );
          })}

          <circle className="token fill-accent" cx={token.x} cy={token.y} r="5" pointerEvents="none" />
        </svg>
      </div>

      <p className="max-w-xl text-lg leading-snug text-fg">
        {compose ? COMPOSED_META[mode].line : MODE_META[mode].line}
      </p>
      <p className="max-w-xl text-sm text-muted">
        {undo.self
          ? `This rule undoes itself. ${undo.factor} again retraces the step.`
          : `Undo is ${MODE_META[undo.mode].label}${undo.compose ? " with Compose −1" : ""}, ${undo.factor}. Same roads, opposite arrows.`}
      </p>

      <div className="flex flex-col gap-4">
        <div>
          <p className="font-mono text-xs tracking-wide text-faint uppercase">
            Residue {residue}
            {mirrorHere ? " · on the complement" : ""}
          </p>
          <div className="mt-2 flex gap-1" aria-label="Digit block">
            {chars.map((ch, i) => (
              <span
                key={`${mode}-${i}`}
                className={
                  "flex h-12 items-center justify-center rounded-md bg-surface font-mono text-xl text-fg tabular-nums " +
                  (chars.length === 2 ? "w-12" : "w-9")
                }
              >
                {ch}
              </span>
            ))}
          </div>
          <p className="mt-2 max-w-md text-sm text-muted">
            {next === residue
              ? "This state stays where it is."
              : mirrorHere
                ? compose
                  ? "The composed step lands on the complement."
                  : "This step is the complement. The arrow and the mirror are the same."
                : compose
                  ? "These arrows are the step composed with −1. The dashed chord is the complement alone."
                  : "The dashed chord is the complement alone. It is not this step composed with −1."}
          </p>
        </div>
        <div className="flex flex-wrap gap-2" aria-label="Orbit">
          {walk.map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setResidue(r)}
              className={
                "min-h-11 min-w-11 rounded-full border font-mono text-sm " +
                (r === residue
                  ? "border-accent bg-accent text-ink"
                  : "border-line bg-surface text-fg")
              }
              aria-label={`Go to residue ${r}`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
